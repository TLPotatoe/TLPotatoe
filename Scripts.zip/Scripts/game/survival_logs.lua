log_mechanicstation = "29d72e47-8eac-4fb9-95b1-ecccc06ff84f"
log_crashedship = "ee4ab0d3-027a-4969-9436-5b23c26e5eeb"

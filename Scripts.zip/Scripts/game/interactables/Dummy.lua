Dummy = class()
Dummy.maxParentCount = 255
Dummy.maxChildCount = 255
Dummy.connectionInput = sm.interactable.connectionType.logic
Dummy.connectionOutput = sm.interactable.connectionType.logic

--Does nothing, but sm.cell.getInteractablesByUuid will only find interactables.
